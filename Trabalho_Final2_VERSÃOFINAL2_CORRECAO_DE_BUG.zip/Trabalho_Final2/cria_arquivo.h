void gera_arquivo(int *vet100, int *vet1000, int *vet10000, int *vet100000, int *libera);
void ordena(int *vet100, int *vet1000, int *vet10000, int *vet100000, int *libera_ordena);
