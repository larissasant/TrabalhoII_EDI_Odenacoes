/*
                        ORDENA��O
IDE: Codeblocks
Vers�o: 16.01
Compilador:GNU GCC

Disciplina: Estrutura de Dados I
Professor: Filipe Dwan Pereira
Alunos: Jo�o Paulo Parreira Peixoto e Larissa Santos Silva

Reposit�rio Github: https://github.com/larissasant/TrabalhoII_EDI_Odenacoes.git
*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <locale.h> //biblioteca que contem os acentos
#include <time.h>
#include <windows.h>
#include "funcoes.h"
#include "cria_arquivo.h"

int main(){
    setlocale(LC_ALL, "Portuguese");
    int x=0, troca=0, comparar=0;
    unsigned long long int compara=0, trocar=0;
    int valor;
    int vet100[100], vet1000[1000], vet10000[10000], vet100000[100000];
    srand(time(NULL));
    int libera = 0, libera_ordena = 0;

    do{
        system("cls");
        printf(" \t\tORDENA��O\n");
        printf("\n 1 - Gerar Arquivo\n 2 - Ordenar Arquivo\n 3 - Busca\n 0 - Sair\n");
        printf("Op��o: ");
        scanf("%d", &x);

        switch (x){
            //arquivo 1
        case 1:{

            gera_arquivo(vet100, vet1000, vet10000, vet100000, &libera);

            printf("\nAperte <Enter> para continuar...\n");
            getch();
            break;
        }

        case 2:{
            if (libera == 0){
                system("cls");
                printf("\n\n\n\n\n\n\n\n\n\n\t\t\t    GERE O ARQUIVO PRIMEIRO!\n");
                Sleep(2000);
                break;
            }
            system("cls");//limpar
            int opMenu2;
            do{
                printf("\t\t\t\tOrdenar Arquivo\n");
                printf ("\nEscolha um algoritmo para ordenar e saber detalhadamente: \n\n\t->Tempo de execu��o\n\t->Trocas Realizadas\n\t->Compara��es realizadas\nOp��o:");
                printf("\n\n\t\t1 - Insertion Sort\n\t\t2 - Selection Sort\n\t\t3 - Bubble Sort \n\t\t4 - Radix Sort\n\t\t5 - Quick Sort\n\t\t6 - Merge Sort\n\t\t7 - Heap Sort\n\t\t0 - Voltar\n");
                printf("Op��o: ");
                setbuf(stdin,NULL);
                scanf("%d",&opMenu2);

                switch(opMenu2){

                    case 1:{ // INSERTION SORT
                        system("cls");
                        double insertion_time;

                        insertionSort(vet100, 100, &insertion_time, &compara, &troca);

                        printf("\n\t\t\t   INSERTION SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 100\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet100 teve %d trocas\t\t\t  *\n\t*  Fun��o vet100 teve %d compara��es\t\t  *\n\t*  Fun��o vet100 executou em %lf segundos\t  *\n",troca, compara, insertion_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        insertionSort(vet1000, 1000, &insertion_time, &compara, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 1000\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet1000 teve %d trocas\t\t  *\n\t*  Fun��o vet1000 teve %lld compara��es\t  *\n\t*  Fun��o vet1000 executou em %lf segundos\t  *\n",troca, compara, insertion_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        insertionSort(vet10000, 10000, &insertion_time, &compara, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 10000\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet10000 teve %d trocas\t\t  *\n\t*  Fun��o vet10000 teve %lld compara��es\t  *\n\t*  Fun��o vet10000 executou em %lf segundos  *\n",troca, compara, insertion_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        insertionSort(vet100000, 100000, &insertion_time, &compara, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 100000\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet100000 teve %d trocas\t\t  *\n\t*  Fun��o vet100000 teve %lld compara��es\t  *\n\t*  Fun��o vet100000 executou em %lf segundos *\n",troca, compara, insertion_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }

                    case 2:{
                        system("cls");
                        double selection_time;

                        selection_sort(vet100, 100, &selection_time, &comparar, &troca);

                        printf("\n\t\t\t   SELECTION SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 100\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet100 teve %d trocas\t\t\t    *\n\t*  Fun��o vet100 teve %d compara��es\t\t    *\n\t*  Fun��o vet100 executou em %lf segundos\t    *\n",troca, comparar, selection_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        selection_sort(vet1000, 1000, &selection_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 1000\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet1000 teve %d trocas\t\t    *\n\t*  Fun��o vet1000 teve %d compara��es\t    *\n\t*  Fun��o vet1000 executou em %lf segundos\t    *\n",troca, comparar, selection_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        selection_sort(vet10000, 10000, &selection_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 10000\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet10000 teve %d trocas\t\t    *\n\t*  Fun��o vet10000 teve %d compara��es\t    *\n\t*  Fun��o vet10000 executou em %lf segundos    *\n",troca, comparar, selection_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        selection_sort(vet100000, 100000, &selection_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 100000\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet100000 teve %d trocas\t\t    *\n\t*  Fun��o vet100000 teve %d compara��es\t    *\n\t*  Fun��o vet100000 executou em %lf segundos  *\n",troca, comparar, selection_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }

                    case 3:{
                        system("cls");
                        double bubble_time;

                        bubble_sort(vet100, 100, &bubble_time, &comparar, &trocar);

                        printf("\n\t\t\t   BUBBLE SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 100\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet100 teve %lld trocas\t\t    *\n\t*  Fun��o vet100 teve %d compara��es\t\t    *\n\t*  Fun��o vet100 executou em %lf segundos\t    *\n",trocar, comparar, bubble_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        troca = 0, comparar = 0;
                        bubble_sort(vet1000, 1000, &bubble_time, &comparar, &trocar);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 1000\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet1000 teve %lld trocas\t\t    *\n\t*  Fun��o vet1000 teve %d compara��es\t    *\n\t*  Fun��o vet1000 executou em %lf segundos\t    *\n",trocar, comparar, bubble_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        troca = 0, comparar = 0;
                        bubble_sort(vet10000, 10000, &bubble_time, &comparar, &trocar);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 10000\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet10000 teve %lld trocas\t\t    *\n\t*  Fun��o vet10000 teve %d compara��es\t    *\n\t*  Fun��o vet10000 executou em %lf segundos    *\n",trocar, comparar, bubble_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        troca = 0, comparar = 0;
                        bubble_sort(vet100000, 100000, &bubble_time, &comparar, &trocar);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 100000\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Fun��o vet100000 teve %lld trocas\t    *\n\t*  Fun��o vet100000 teve %d compara��es\t    *\n\t*  Fun��o vet100000 executou em %lf segundos  *\n",trocar, comparar, bubble_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }

                    case 4:{
                        system("cls");
                        double radix_time;


                        radixsort(vet100, 100, &radix_time);

                        printf("\n\t\t\t   RADIX SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 100\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Funcao vet100 executou em %f segundos\t    *\n", radix_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        radixsort(vet1000, 1000, &radix_time);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 1000\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Funcao vet1000 executou em %f segundos\t    *\n", radix_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        radixsort(vet10000, 10000, &radix_time);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 10000\t\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Funcao vet10000 executou em %f segundos    *\n", radix_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        radixsort(vet100000, 100000, &radix_time);

                        printf("\t*\t\t\t\t\t\t    *\n\t*\t\t VETOR DE 100000\t\t    *\n\t*\t\t\t\t\t\t    *\n");
                        printf("\t*  Funcao vet100000 executou em %f segundos   *\n", radix_time);
                        printf("\t*\t\t\t\t\t\t    *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }
                    case 5:{
                        system("cls");
                        double quick_time;

                        quick(vet100, 0, 99, &quick_time, &comparar, &troca);

                        printf("\n\t\t\t   QUICK SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t        *\n\t*\t\t VETOR DE 100\t\t\t        *\n\t*\t\t\t\t\t\t        *\n");
                        printf("\t*\tFun��o vet100 teve %d trocas\t\t        *\n\t*\tFun��o vet100 teve %d compara��es\t        *\n\t*\tFun��o vet100 executou em %lf segundos     *\n",troca, comparar, quick_time);
                        printf("\t*\t\t\t\t\t\t        *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        Sleep(1000);

                        comparar = 0, troca = 0;

                        quick(vet1000, 0, 999, &quick_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t        *\n\t*\t\t VETOR DE 1000\t\t\t        *\n\t*\t\t\t\t\t\t        *\n");
                        printf("\t*\tFun��o vet1000 teve %d trocas\t\t        *\n\t*\tFun��o vet1000 teve %d compara��es\t        *\n\t*\tFun��o vet1000 executou em %lf segundos    *\n",troca, comparar, quick_time);
                        printf("\t*\t\t\t\t\t\t        *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;

                        quick(vet10000, 0, 9999, &quick_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t        *\n\t*\t\t VETOR DE 10000\t\t\t        *\n\t*\t\t\t\t\t\t        *\n");
                        printf("\t*\tFun��o vet10000 teve %d trocas\t        *\n\t*\tFun��o vet10000 teve %d compara��es        *\n\t*\tFun��o vet10000 executou em %lf segundos   *\n",troca, comparar, quick_time);
                        printf("\t*\t\t\t\t\t\t        *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;

                        quick(vet100000, 0, 99999, &quick_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t        *\n\t*\t\t VETOR DE 100000\t\t        *\n\t*\t\t\t\t\t\t        *\n");
                        printf("\t*\tFun��o vet100000 teve %d trocas\t        *\n\t*\tFun��o vet100000 teve %d compara��es     *\n\t*\tFun��o vet100000 executou em %lf segundos  *\n",troca, comparar, quick_time);
                        printf("\t*\t\t\t\t\t\t        *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }
                    case 6:{
                        system("cls");
                        double merge_time;

                        comparar = 0, troca = 0;
                        mergeSort(vet100, 0, 99, &merge_time, &comparar, &troca);

                        printf("\n\t\t\t   MERGE SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 100\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet100 teve %d trocas\t\t  *\n\t*  Fun��o vet100 teve %d compara��es\t\t  *\n\t*  Fun��o vet100 executou em %lf segundos\t  *\n",troca, comparar, merge_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;
                        mergeSort(vet1000, 0, 999, &merge_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 1000\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet1000 teve %d trocas\t\t  *\n\t*  Fun��o vet1000 teve %d compara��es\t\t  *\n\t*  Fun��o vet1000 executou em %lf segundos\t  *\n",troca, comparar, merge_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;
                        mergeSort(vet10000, 0, 9999, &merge_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 10000\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet10000 teve %d trocas\t\t  *\n\t*  Fun��o vet10000 teve %d compara��es\t  *\n\t*  Fun��o vet10000 executou em %lf segundos  *\n",troca, comparar, merge_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;
                        mergeSort(vet100000, 0, 99999, &merge_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 100000\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet100000 teve %d trocas\t\t  *\n\t*  Fun��o vet100000 teve %d compara��es\t  *\n\t*  Fun��o vet100000 executou em %lf segundos *\n",troca, comparar, merge_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }
                    case 7:{
                        system("cls");
                        double heap_time;

                        comparar = 0, troca = 0;

                        heapSort(vet100, 0, 100, &heap_time, &comparar, &troca);

                        printf("\n\t\t\t   HEAP SORT \n\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 100\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet100 teve %d trocas\t\t  *\n\t*  Fun��o vet100 teve %d compara��es\t\t  *\n\t*  Fun��o vet100 executou em %lf segundos\t  *\n",troca, comparar, heap_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;
                        heapSort(vet1000, 0, 1000, &heap_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 1000\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet1000 teve %d trocas\t\t  *\n\t*  Fun��o vet1000 teve %d compara��es\t  *\n\t*  Fun��o vet1000 executou em %lf segundos\t  *\n",troca, comparar, heap_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;
                        heapSort(vet10000, 0, 10000, &heap_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 10000\t\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet10000 teve %d trocas\t\t  *\n\t*  Fun��o vet10000 teve %d compara��es\t  *\n\t*  Fun��o vet10000 executou em %lf segundos  *\n",troca, comparar, heap_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");
                        Sleep(1000);

                        comparar = 0, troca = 0;
                        heapSort(vet100000, 0, 100000, &heap_time, &comparar, &troca);

                        printf("\t*\t\t\t\t\t\t  *\n\t*\t\t VETOR DE 100000\t\t  *\n\t*\t\t\t\t\t\t  *\n");
                        printf("\t*  Fun��o vet100000 teve %d trocas\t\t  *\n\t*  Fun��o vet100000 teve %d compara��es\t  *\n\t*  Fun��o vet100000 executou em %lf segundos *\n",troca, comparar, heap_time);
                        printf("\t*\t\t\t\t\t\t  *\n\t* * * * * * * * * * * * * * * * * * * * * * * * * *\n");

                        printf("\nAperte <Enter> para continuar...\n");
                        getch();

                        ordena(vet100, vet1000, vet10000, vet100000, &libera_ordena);

                        break;
                    }

                }

                Sleep(1000);
                system("cls");
                if(opMenu2 != 0 && opMenu2 <= 7){
                    printf("Escolha Outra op��o\n");
                }

                if(opMenu2 > 7){
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\t\t       Op��o Inv�lida, Tente Novamente!");
                    Sleep(1000);
                    system("cls");
                    continue;
                }
            }
            while (opMenu2 != 0);
            break;
        }

        case 3:{
        do{
                system("cls");
                printf("\t\t\t\tBusca\n");
                printf("Escolha o tipo de busca que deseja fazer:\n\t1 - Busca Linear\n\t2 - Busca Bin�ria\n\t0 - Voltar\n");
                printf("Op��o: ");
                setbuf(stdin, NULL);
                scanf("%d", &x);

                switch(x){
                    case 1:{
                        if (libera == 0){
                        system("cls");
                        printf("\n\n\n\n\n\n\n\n\n\n\t\t\t    GERE O ARQUIVO PRIMEIRO!\n");
                        Sleep(2000);
                        break;
                        }
                        system("cls");
                        printf("\t\t\t\tBusca Linear\n");

                        printf("\n\nDigite o elemento a ser buscado no vet[100]: ");
                        scanf("%d", &valor);
                        buscaLinear(vet100, 100, valor);
                        printf("\n\nDigite o elemento a ser buscado no vet[1000]: ");
                        scanf("%d", &valor);
                        buscaLinear(vet1000, 1000, valor);
                        printf("\n\nDigite o elemento a ser buscado no vet[10000]: ");
                        scanf("%d", &valor);
                        buscaLinear(vet10000, 10000, valor);
                        printf("\n\nDigite o elemento a ser buscado no vet[100000]: ");
                        scanf("%d", &valor);
                        buscaLinear(vet100000, 100000, valor);
                        printf("\nCaso queira, fa�a novas buscas.\n");

                        Sleep(2000);
                        break;
                    }

                    case 2:{
                        if (libera == 0 || libera_ordena == 0){
                            system("cls");
                            printf("\n\n\n\n\n\n\n\n\n\n\t\t\t    GERE O ARQUIVO PRIMEIRO!\n");
                            if (libera == 1 && libera_ordena == 0){
                                system("cls");
                                printf("\n\n\n\n\n\n\n\n\n\n\t\t    GERE O ARQUIVO NOVAMENTE E O ORDENE!\n");
                            }
                        Sleep(2500);
                        break;
                        }
                        system("cls");
                        printf("\t\t\t\tBusca Bin�ria\n");

                        printf("\n\nDigite o elemento a ser buscado no vet[100]: ");
                        scanf("%d", &valor);
                        buscaBinaria(vet100, 100, valor);
                        printf("\n\nDigite o elemento a ser buscado no vet[1000]: ");
                        scanf("%d", &valor);
                        buscaBinaria(vet1000, 1000, valor);
                        printf("\n\nDigite o elemento a ser buscado no vet[10000]: ");
                        scanf("%d", &valor);
                        buscaBinaria(vet10000, 10000, valor);
                        printf("\n\nDigite o elemento a ser buscado no vet[100000]: ");
                        scanf("%d", &valor);
                        buscaBinaria(vet100000, 100000, valor);
                        printf("\nCaso queira, fa�a novas buscas.\n");

                        Sleep(2500);
                        break;
                    }
                    case 0:{
                        if(x == 0){
                            return main();
                        }
                    }
                }
            }while (x != 0);
        }


        case 0:{
            system("cls");
            printf("\n\n\n\t\t\t    THE END!\n\n\n");
            exit(1);
            }

        default:{
            system("cls");
            printf("\n\n\n\n\n\n\n\n\n\t\t       Op��o Inv�lida, Tente Novamente!");
            Sleep(2500);
            system("cls");
            break;
            }

        }
    }while (x != 0);

    return 0;
}
