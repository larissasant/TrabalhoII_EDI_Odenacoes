void insertionSort(int *vet, int tam, double *insertion_time,unsigned long long int *compara, int *troca);
void buscaLinear(int vet[], int tam, int elemento);
void selection_sort(int num[], int tam, double *selection_time, int *comparar, int *troca);
void bubble_sort(int *vet, int tam, double *bubble_time, int *comparar,unsigned long long int *trocar);
void radixsort(int vetor[], int tamanho, double *radix_time);
void quick(int *V, int inicio, int fim, double *quick_time, int *comparar, int *troca);
void mergeSort (int *vet, int inicio, int fim, double *merge_time, int *comparar, int *troca);
void heapSort(int *vet,int inicio, int tam, double *heap_time, int *comparar, int *troca);
int buscaBinaria(int *vet, int tam, int elemento);
