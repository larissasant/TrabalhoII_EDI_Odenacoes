#include "cria_arquivo.h"
#include <stdlib.h>
#include <stdio.h>

int i;
void gera_arquivo(int *vet100, int *vet1000, int *vet10000, int *vet100000, int *libera){
    system("cls");//limpar tela
                printf("1 - Gerar Arquivo\n\n");
                FILE *arquivo100;
                arquivo100 = fopen("arquivo100.txt", "w"); //abre o arquivo de texto pra gravar
                for(i=0; i<100; i++){
                    fprintf (arquivo100, "%d\t", ( rand() % 101 ));// saida do arquivo
                }
                fclose(arquivo100);//fecha o arquivo
                printf("Tamanho do Arquivo: 100\n");

                arquivo100 = fopen("arquivo100.txt", "r");
                for (i=0; i<100; i++){
                    fscanf(arquivo100, "%d", &vet100[i]);
                }
                fclose(arquivo100);

                //aquivo 2
                FILE *arquivo1000;
                arquivo1000 = fopen("arquivo1000.txt", "w");//abrir o arquivo e gravar
                for(i=0; i<1000; i++){ //percorrer o arquivo
                    fprintf(arquivo1000, "%d\t",( rand() % 101 ));
                }
                fclose(arquivo1000);//fechar arquivo2
                printf("Tamanho do Arquivo: 1000\n");

                arquivo1000 = fopen("arquivo1000.txt", "r");
                for (i=0; i<1000; i++){
                    fscanf(arquivo1000, "%d", &vet1000[i]);
                }
                fclose(arquivo1000);

                //arquivo 3
                FILE *arquivo10000;
                arquivo10000 = fopen("arquivo10000.txt", "w");
                for(i=0; i< 10000; i++){
                    fprintf(arquivo10000,"%d\t", ( rand() % 101 ));
                }
                fclose(arquivo10000);
                printf("Tamanho do Arquivo: 10000\n");

                arquivo10000 = fopen("arquivo10000.txt", "r");
                for (i=0; i<10000; i++){
                    fscanf(arquivo10000, "%d", &vet10000[i]);
                }
                fclose(arquivo10000);

                //arquivo 4
                FILE *arquivo100000;
                arquivo100000 = fopen("arquivo100000.txt", "w");
                for(i=0; i<100000; i++){
                    fprintf(arquivo100000,"%d\t", ( rand() % 101 ));
                }
                fclose(arquivo100000);
                printf("Tamanho do Arquivo: 100000\n");

                arquivo100000 = fopen("arquivo100000.txt", "r");
                for (i=0; i<100000; i++){
                    fscanf(arquivo100000, "%d", &vet100000[i]);
                }
                fclose(arquivo100000);

                *libera = 1;
}

void ordena(int *vet100, int *vet1000, int *vet10000, int *vet100000, int *libera_ordena){
                        //ARQUIVO100
                        FILE *arquivo100_Ordenado;
                        arquivo100_Ordenado = fopen("arquivo100_Ordenado.txt", "w");

                        for (i = 0; i < 100; i++){
                            fprintf(arquivo100_Ordenado, "%d\t", vet100[i]);
                        }

                        fclose(arquivo100_Ordenado);

                        //ARQUIVO1000
                        FILE *arquivo1000_Ordenado;
                        arquivo1000_Ordenado = fopen("arquivo1000_Ordenado.txt", "w");

                        for (i = 0; i < 1000; i++){
                            fprintf(arquivo1000_Ordenado, "%d\t", vet1000[i]);
                        }

                        fclose(arquivo1000_Ordenado);

                        //ARQUIVO10000
                        FILE *arquivo10000_Ordenado;
                        arquivo10000_Ordenado = fopen("arquivo10000_Ordenado.txt", "w");

                        for (i = 0; i < 10000; i++){
                            fprintf(arquivo10000_Ordenado, "%d\t", vet10000[i]);
                        }

                        fclose(arquivo10000_Ordenado);

                         //ARQUIVO100000
                        FILE *arquivo100000_Ordenado;
                        arquivo100000_Ordenado = fopen("arquivo100000_Ordenado.txt", "w");

                        for (i = 0; i < 100000; i++){
                            fprintf(arquivo100000_Ordenado, "%d\t", vet100000[i]);
                        }

                        fclose(arquivo100000_Ordenado);
    *libera_ordena = 1;
}
