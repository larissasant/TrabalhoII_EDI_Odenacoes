#include "funcoes.h"
#include <time.h>
#include <stdlib.h>
#include <stdio.h>

void insertionSort(int *vet, int tam, double *insertion_time,unsigned long long int *compara, int *troca){
    clock_t start_time;
    start_time = clock();
    *compara = 0;
    *troca = 0;

    int i, j, aux;

    for(i = 1; i < tam; i++){
        aux = vet[i];
        for(j = i; (j > 0) && (aux < vet[j - 1]); j--){
            *compara+=1;
            vet[j] = vet[j - 1];
        }
        vet[j] = aux;
        *troca+=1;
    }

    *insertion_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void selection_sort(int *vet, int tam, double *selection_time, int *comparar, int *troca){
    clock_t start_time;
    start_time = clock();

    *comparar = 0;
    *troca = 0;

    int i, j, menor, aux;
    for (i = 0; i < tam-1; i++){
        menor = i;
        for (j = i+1; j < tam; j++){
            if(vet[j] < vet[menor]){
                menor = j;
            }
            *comparar+=1;
        }
        if (i != menor){
            aux = vet[i];
            vet[i] = vet[menor];
            vet[menor] = aux;
            *troca+=1;
        }
    }

    *selection_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void bubble_sort(int vet[], int tam, double *bubble_time, int *comparar, unsigned long long int *troca){
    clock_t start_time;
    start_time = clock();

    int i, j, aux;

    for (i = 0 ; i < ( tam - 1 ); i++){
        for (j = 0 ; j < tam - i - 1; j++){
            if (vet[j] > vet[j+1]){
                /* Swapping */
                aux         = vet[j];
                vet[j]   = vet[j+1];
                vet[j+1] = aux;
                *troca+=1;
             }
             *comparar+=1;
         }
     }

     *bubble_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void radixsort(int vetor[], int tamanho, double *radix_time) {
    clock_t start_time;
    start_time = clock();

    int *b;
    int maior = vetor[0];
    int i, exp = 1;

    b = (int *)calloc(tamanho, sizeof(int));

    for (i = 0; i < tamanho; i++) {
        if (vetor[i] > maior)
            maior = vetor[i];
    }

    while (maior/exp > 0) {
        int bucket[10] = { 0 };
        for (i = 0; i < tamanho; i++)
            bucket[(vetor[i] / exp) % 10]++;
            for (i = 1; i < 10; i++)
                bucket[i] += bucket[i - 1];
                for (i = tamanho - 1; i >= 0; i--)
                    b[--bucket[(vetor[i] / exp) % 10]] = vetor[i];
                    for (i = 0; i < tamanho; i++)
                        vetor[i] = b[i];
                        exp *= 10;
    }

    free(b);

    *radix_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void quick(int *V, int inicio, int fim, double *quick_time, int *comparar, int *troca){
    clock_t start_time;
    start_time = clock();

    int particiona(int *V, int inicio, int fim){
        int esq, dir, pivo, aux;
        esq = inicio;
        dir = fim;
        pivo = V[inicio];

        while(esq < dir){
                *comparar+=1;
            while (V[esq] <= pivo){
                *comparar+=1;
                esq++;
            }
            while (V[dir] > pivo){
                *comparar+=1;
                dir--;
            }
            if (esq < dir){
                *troca+=1;
                aux = V[esq];
                V[esq] = V[dir];
                V[dir] = aux;
            }
        }
        V[inicio] = V[dir];
        V[dir] = pivo;

        return dir;
    }

    int pivo;
        if(fim > inicio){
            *comparar+=1;
            pivo = particiona(V, inicio, fim);
            quick(V, inicio, pivo-1, quick_time, comparar, troca);
            quick(V, pivo+1, fim, quick_time, comparar, troca);
        }

    *quick_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void mergeSort (int *vet, int inicio, int fim, double *merge_time, int *comparar, int *troca){
    clock_t start_time;
    start_time = clock();

    void merge(int *vet, int inicio, int meio, int fim){
        int *aux, p1, p2, tam, i, j, k;
        int fim1 = 1, fim2 = 1;
        tam = fim-inicio+1;
        p1 = inicio;
        p2 = meio +1;

        aux = (int *) malloc(tam*sizeof(int));

        for (i = 0; i < tam; i++){
            if(fim1 && fim2){
                    *comparar+=1;
                    //*troca+=1;
                if(vet[p1] < vet[p2]){
                    aux[i] = vet[p1++];
                }
                else{
                    aux[i] = vet[p2++];
                }
                if(p1 > meio)
                    fim1 = 0;
                if(p2 > fim)
                    fim2 = 0;
            }
            else{
                    *troca+=1;
                if(fim1){
                    aux[i] = vet[p1++];
                }
                else{

                    aux[i] = vet[p2++];
                }
            }
        }
        for(j = 0, k = inicio; j < tam; j++, k++){
            vet[k] = aux[j];
        }

        free(aux);
    }

    int meio;
    if (inicio < fim){
        meio = (inicio + fim)/2;
        mergeSort(vet, inicio, meio, merge_time, comparar, troca);
        mergeSort(vet, meio+1, fim, merge_time, comparar, troca);
        merge(vet, inicio, meio, fim);
    }

    *merge_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void heapSort(int *vet, int inicio, int tam, double *heap_time, int *comparar, int *troca){
    clock_t start_time;
    start_time = clock();

    void criaHeap(int *vet, int i, int f){
        int aux = vet[i];
        int j = i*2+1;
        while (j <= f){
            if (j < f){
                *comparar+=1;
                if (vet[j] < vet[j + 1]){
                    j++;
                }
            }
            *comparar+=1;
            if(aux < vet[j]){
                *troca+=1;
                vet[i] = vet[j];
                i = j;
                j = 2 * i + 1;
            }
            else{
                j = f + 1;
            }
        }
        vet[i] = aux;
    }

        int i, aux;

        for (i = (tam-1)/2; i >= 0; i--){
            criaHeap(vet, i, tam-1);
        }

        for (i = tam-1; i >= 1; i--){
            *troca+=1;
            aux = vet[0];
            vet[0] = vet[i];
            vet[i] = aux;
            criaHeap(vet, 0 , i-1);
        }

        *heap_time = ((double)clock() - start_time) / (double)CLOCKS_PER_SEC;
}

void buscaLinear(int vet[], int tam, int elemento){
    int i;
    int *aux ;
    aux = (int *) malloc(tam*sizeof(int));

    if (tam == 100){
        FILE *arquivo100;
        arquivo100 = fopen("arquivo100.txt", "r");
        for (i=0; i<tam; i++){
            fscanf(arquivo100, "%d", &aux[i]);
        }
        fclose(arquivo100);
    }
    if (tam == 1000){
        FILE *arquivo1000;
        arquivo1000 = fopen("arquivo1000.txt", "r");
        for (i=0; i<tam; i++){
            fscanf(arquivo1000, "%d", &aux[i]);
        }
        fclose(arquivo1000);
    }
    if (tam == 10000){
        FILE *arquivo10000;
        arquivo10000 = fopen("arquivo10000.txt", "r");
        for (i=0; i<tam; i++){
            fscanf(arquivo10000, "%d", &aux[i]);
        }
        fclose(arquivo10000);
    }
    if (tam == 100000){
        FILE *arquivo100000;
        arquivo100000 = fopen("arquivo100000.txt", "r");
        for (i=0; i<tam; i++){
            fscanf(arquivo100000, "%d", &aux[i]);
        }
        fclose(arquivo100000);
    }

    for (i = 0; i < tam; i++){
        if (aux[i] == elemento){
            printf("\nValor %d encontrado na posi��o %d.\n", aux[i], i);
        }
    }

    for (i = 0; i < tam; i++){
        if (aux[i] == elemento){
            break;
        }
    }
    if (aux[i] != elemento)
        printf("\nValor n�o encontrado\n");

    free(aux);
}

int buscaBinaria(int *vet, int tam, int elemento){
    int inicio, meio, fim;
    inicio = 0;
    fim = tam-1;

    while(inicio <= fim){
        meio = (inicio + fim)/2;
        if (elemento < vet[meio])
            fim = meio - 1;
        else
            if (elemento > vet[meio])
            inicio = meio + 1;
            else{
            printf("\nElemento %d encontrado.\n", elemento);
            return meio;
            }
    }
    printf("\nElemento n�o encontrado.\n");

    return -1;
}
